# Solo Leveling App

A self-improvement tracker inspired by Solo Leveling.